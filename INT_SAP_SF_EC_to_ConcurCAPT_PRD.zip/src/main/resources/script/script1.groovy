import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message buildQuery(Message message) {
    
	//Get content of body
	def body = message.getBody(String.class); 
	
	//Get content of property
	def map = message.getProperties();
	def company = map.get("propCompany");
	
	company = company.replace(",","','")
	
	String queryWhere = '';
	
	queryWhere = "&\$filter=(userNav/status eq 't' or userNav/status eq 'f') and assignmentClass eq 'ST' and jobInfoNav/company in '" + company + "'";
	
	message.setProperty("queryWhere", queryWhere);
	
	
	//return message properties
	return message;
	
}